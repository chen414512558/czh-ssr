import './header.less';
import _logo from './img/logo.png';
class Header {
    constructor() {
        console.log('这是头');
        this.init();
    }

    init() {
        document.getElementById('logo').src = _logo;
    }
}

export default Header;